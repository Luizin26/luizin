var tentativas = 0;
function pegatexto() {
    var usuario = document.querySelector('#usuario');
    var senha = document.querySelector('#senha');
    if ((usuario === null || usuario === void 0 ? void 0 : usuario.value) == "AlunoSSESI2023" && (senha === null || senha === void 0 ? void 0 : senha.value) == "devsistemas") {
        window.location.href = "./bemvindo.html";
    }
    else if (tentativas < 5) {
        alert('senha ou usuario incorretos');
        tentativas++;
    }
    if (tentativas >= 5) {
        window.location.href = "./bloqueado.html";
    }
}

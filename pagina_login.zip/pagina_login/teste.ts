
let tentativas = 0;
function pegatexto(){
let usuario : HTMLInputElement | null = document.querySelector('#usuario') ;
let senha : HTMLInputElement | null = document.querySelector('#senha');
    if (usuario?.value == "AlunoSSESI2023" && senha?.value == "devsistemas"){
        window.location.href="./bemvindo.html"
    }
    else if (tentativas < 5) {
     alert('senha ou usuario incorretos')
        tentativas++
    }
    
    if(tentativas >= 5){
        window.location.href="./bloqueado.html"
    }
}